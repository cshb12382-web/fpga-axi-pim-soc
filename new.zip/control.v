`timescale 1ns / 1ps

module control(
    input clk,
    input rst,

    input [15:0] ir_in,      // ���� ���ɾ� (IR)
    input zero_flag,         // AC�� 0�ΰ�? (Skip��)
    
    input [15:0] ac_in,
    input e_in,
    input [15:0] dr_in,


    output reg [2:0] bus_sel,
    output reg [3:0] alu_op,
    output reg ld_pc, inc_pc, clr_pc,
    output reg ld_ar, inc_ar, clr_ar,
    output reg ld_ir,
    output reg ld_dr, inc_dr, clr_dr,
    output reg ld_ac, clr_ac,
    output reg mem_write,     // �޸� ���� ��ȣ
    
    output reg halt_sig
    );

    // --- ���� ��ȣ ---
    reg [3:0] sc;    // Sequence Counter (0~15) : T0, T1, T2... �ð� ���
    reg sc_clr;
    
    reg s;
    
    // ���ɾ� �ؼ� (Decode)
    wire [2:0] opcode = ir_in[14:12]; // Opcode (3��Ʈ)
    wire indirect = ir_in[15];    // I ��Ʈ (15��)

    // Opcode�� �б� ���� ���� (�Ķ����)
    parameter AND = 3'b000;
    parameter ADD = 3'b001;
    parameter LDA = 3'b010;
    parameter STA = 3'b011;
    parameter BUN = 3'b100;
    parameter BSA = 3'b101;
    parameter ISZ = 3'b110;

    always @(posedge clk or negedge rst) begin
        if(!rst) begin
            sc <= 0;
            s<=1;
        end
        else begin
            if(s==1) begin
                if(halt_sig==1)
                    s<=0;
                else if(sc_clr==1)begin
                    sc<=0;
                end
                else begin
                    sc <= sc + 1;
                end
            end 
        end
    end


    always @(*) begin
        // [�⺻�� ����] (Latch ����: ��� ��ȣ�� �ϴ� 0���� ��)
        bus_sel = 3'b000;
        alu_op  = 4'd0;
        ld_pc = 0; inc_pc = 0; clr_pc = 0;
        ld_ar = 0; inc_ar = 0; clr_ar = 0;
        ld_ir = 0;
        ld_dr = 0; inc_dr = 0; clr_dr = 0;
        ld_ac = 0; clr_ac = 0;
        mem_write = 0;
        sc_clr=0;
        halt_sig=0;


        case(sc)
            4'd0: begin // T0: AR <- PC
                bus_sel = 3'b010; // Bus = PC
                ld_ar   = 1;      // AR Load
            end

            4'd1: begin // T1: IR <- M[AR], PC <- PC + 1
                bus_sel = 3'b110; // Bus = Memory
                ld_ir   = 1;      // IR Load
                inc_pc  = 1;      // PC Increment
            end

            4'd2: begin // T2: Decode (Opcode Ȯ�� & AR <- IR[11:0])
                bus_sel = 3'b011; // Bus = IR (���� 12��Ʈ)
                ld_ar   = 1;
            end

            4'd3: begin
                if(opcode == 3'b111 && indirect ==0)begin
                    if (ir_in[11:5] != 0) begin
                        alu_op = 4'h7; // ALU���� "�������� ������!" ����
                        ld_ac  = 1;    // ��� ����
                    end
            // SPA (Skip if Positive): AC[15]�� 0�̸� ���
                    if ((ir_in[11:0] ==  12'h010) && (ac_in[15] == 0)) begin
                        inc_pc = 1;
                    end          
            // SNA (Skip if Negative): AC[15]�� 1�̸� ����
                    if (ir_in[11:0] == 12'h008 && (ac_in[15] == 1)) begin
                        inc_pc = 1;
                    end           
            // SZA (Skip if Zero): AC�� 0�̸�
                    if (ir_in[11:0] == 12'h004 && (ac_in == 16'b0)) begin
                        inc_pc = 1;
                    end     
            // SZE (Skip if Zero E): E�� 0�̸�
                    if (ir_in[11:0]==12'h002 && (e_in == 0)) begin
                        inc_pc = 1;
                    end
                    if (ir_in[11:0]==12'h001) begin
                        ld_dr = 1;
                        bus_sel = 3'b101;
                    end
            // C. HLT (Halt) - IR[0]
                    if (ir_in[11:0]==12'h000) begin
                        halt_sig =1;
                    end

            // ���� ���� -> SC �ʱ�ȭ ��ȣ �߻�
                     sc_clr = 1;
                end
                else begin
                    if(indirect==1)begin
                        bus_sel = 3'b110;
                        ld_ar = 1;
                    end
                    else begin
                    end
                end
            end
            4'd4: begin
                case(opcode)
                    AND : begin
                        bus_sel = 3'b110;
                        ld_dr=1;
                    end
                    ADD: begin
                        bus_sel = 3'b110;
                        ld_dr=1;
                    end
                    LDA: begin
                        bus_sel = 3'b110;
                        ld_dr=1;
                    end
                    STA : begin
                        bus_sel = 3'b101;
                        mem_write=1;
                        sc_clr=1;
                    end
                    BUN : begin
                        bus_sel = 3'b001;
                        ld_pc=1;
                        sc_clr=1;
                    end
                    BSA : begin
                        bus_sel = 3'b010;
                        mem_write=1;
                        inc_ar=1;
                    end
                    ISZ : begin
                        bus_sel = 3'b110;
                        ld_dr=1;
                    end
                  /*  SUB : begin
                        bus_sel = 3'b110;
                        ld_dr=1;
                    end */
                    default : begin
                    end
                endcase
            end
            4'd5 : begin
                case(opcode)
                    AND : begin
                        alu_op = 4'h0;
                        ld_ac=1;
                        sc_clr=1;
                    end
                    ADD : begin
                        alu_op = 4'h1;
                        ld_ac=1;
                        sc_clr=1;
                    end
                    LDA : begin
                        alu_op = 4'h2;
                        ld_ac=1;
                        sc_clr=1;
                    end
                    BSA : begin
                        bus_sel = 3'b001;
                        ld_pc=1;
                        sc_clr=1;
                    end
                    ISZ : begin
                        inc_dr=1;
                    end
                /*    SUB : begin
                        alu_op = 4'h15;
                        ld_ac=1;
                        sc_clr=1;
                    end  */
                    default : begin
                    end
               endcase
            end
            4'd6 : begin
                case(opcode)
                    ISZ : begin
                        bus_sel = 3'b100;
                        mem_write=1;
                        if(dr_in == 0)
                            inc_pc=1;
                        sc_clr=1;
                    end
                    default : begin
                    end
                endcase
            end
        default : begin
        end
        endcase
    end
endmodule