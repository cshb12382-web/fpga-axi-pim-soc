`timescale 1ns / 1ps

module freq_div_100(        // create freq_div_100 module
    input clk_ref,          // declare input signal clk_ref
    input rst,              // declare input signal rst for reset
    output reg clk_div      // declare output signal type reg clk_div
    );

    reg [5:0] cnt;          // declare internal signal array type reg cnt for 6bit numbers

    always @ (posedge clk_ref or posedge rst)       // executes at rising edge of clk or rising edge of rst 
    begin
        if(rst)                                     // when rst is 1
        begin                                       
            cnt <= 6'd0;                            // cnt is 0
            clk_div <= 1'd0;                        // clk_div is 0
        end
        else                                        // when rst is 0
        begin
            if(cnt == 6'd49)                        // when cnt is 49
            begin
                cnt <= 6'd0;                        // cnt is 0
                clk_div <= ~clk_div;                // clk_div is ~clk_div
            end
            else                                    // when cnt isn't 49
            begin
                cnt <= cnt + 1'b1;                  // cnt is cnt + 1
            end
        end
    end
    
endmodule