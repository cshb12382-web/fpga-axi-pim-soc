`timescale 1ns / 1ps

module synchronizer(        // create synchronizer module
    input clk,              // declare input signal clk
    input async_in,         // declare input signal async_in
    output reg sync_out     // declare output signal type reg 'sync_out'
    );

    reg tmp;                // declare internal signal type reg 'tmp'

    always @ (posedge clk)  // executes at rising edge of clk
    begin
        tmp <= async_in;    // temp is async_in
        sync_out <= tmp;    // sync_out is tmp
    end

endmodule