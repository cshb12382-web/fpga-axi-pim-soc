`timescale 1ns / 1ps

module add_sub(
    input [15:0] a,              // declare Input Signal Array 'a' for 4 bit numbers
    input [15:0] b,              // declare Input Signal Array 'b' for 4 bit numbers
    input m,
    output [15:0] sum,           // declare Output Signal Array 'sum' for 4 bit numbers
    output overflow,            // declare Output Signal overflow (overflow=1: overflow detected, overflow=0: overflow not detected)
    output cout                 // declare Output Signal cout
);
    
    wire [15:0] rev_b;
    
    assign rev_b =  (m==1)? ~b + 1'b1 : b;
    
    cla16 u0 (.a(a), .b(rev_b), .cin(1'b0), .sum(sum), .cout(cout));

    assign overflow = (m == 0) ? ((a[15] == b[15]) && (sum[15] != a[15])) :
                              ((a[15] != rev_b[15]) && (sum[15] != a[15]));
       
endmodule
