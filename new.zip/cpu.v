`timescale 1ns / 1ps

module cpu(
    input clk,
    input rst,
    
    output [15:0] w_ac_out, // ���� AC �� (SSD ǥ�ÿ�)
    output w_halt_out,
    output w_ov_out,
    
    input [11:0] uart_addr,
    input [15:0] uart_data,
    input uart_we
        
    
    );

    // ====================================================
    // 1. ���� ���� (Wire) ���� - ��Ⳣ�� �����ϴ� ����
    // ====================================================
    
    // Control -> Datapath ��ȣ
    wire [2:0] w_bus_sel;
    wire [3:0] w_alu_op;
    wire w_ld_pc, w_inc_pc, w_clr_pc;
    wire w_ld_ar, w_inc_ar, w_clr_ar;
    wire w_ld_ir;
    wire w_ld_dr, w_inc_dr, w_clr_dr;
    wire w_ld_ac, w_clr_ac;
    wire w_mem_write;

    // Datapath -> Control/Memory ��ȣ
    wire [15:0] w_ir_out;
    wire [15:0] w_dr_out;
    wire w_e_out;
    
    // Memory ����
    wire [11:0] w_mem_addr;   // AR -> Memory
    wire [15:0] w_bus_data;   // Bus -> Memory (Write Data)
    wire [15:0] w_mem_read_data; // Memory -> Bus (Read Data)
    

    control u_control(
        .clk(clk),
        .rst(rst),
        // Inputs
        .ir_in(w_ir_out),
        .zero_flag(w_ac_out == 16'b0), // AC�� 0���� üũ
        .ac_in(w_ac_out),
        .e_in(w_e_out),
        .dr_in(w_dr_out), 
        
        // Outputs
        .bus_sel(w_bus_sel),
        .alu_op(w_alu_op),
        .ld_pc(w_ld_pc), .inc_pc(w_inc_pc), .clr_pc(w_clr_pc),
        .ld_ar(w_ld_ar), .inc_ar(w_inc_ar), .clr_ar(w_clr_ar),
        .ld_ir(w_ld_ir),
        .ld_dr(w_ld_dr), .inc_dr(w_inc_dr), .clr_dr(w_clr_dr),
        .ld_ac(w_ld_ac), .clr_ac(w_clr_ac),
        .mem_write(w_mem_write),
        .halt_sig(w_halt_out)
    );

    register u_datapath(
        .clk(clk),
        .rst(rst),
        // Control Signals
        .bus_sel(w_bus_sel),  //control
        .alu_op(w_alu_op),  //control
        .ld_pc(w_ld_pc), .inc_pc(w_inc_pc), .clr_pc(w_clr_pc),
        .ld_ar(w_ld_ar), .inc_ar(w_inc_ar), .clr_ar(w_clr_ar),
        .ld_ir(w_ld_ir),
        .ld_dr(w_ld_dr), .inc_dr(w_inc_dr), .clr_dr(w_clr_dr),
        .ld_ac(w_ld_ac), .clr_ac(w_clr_ac),
        .mem_write(w_mem_write),
        
        // Memory Interface
        .mem_in(w_mem_read_data), // RAM���� ���� ������ ����
        .mem_addr(w_mem_addr),    // RAM���� �ּ� ���� (AR)
        .mem_out(w_bus_data),     // RAM���� ������ ���� (Bus)

        // Status
        .ir_out(w_ir_out),
        .ac_out(w_ac_out),
        .dr_out(w_dr_out),
        .e_out(w_e_out),
        .OV(w_ov_out)
    );

    blk_mem_gen_0 u_ram(
        .clka(~clk),
        .wea(w_mem_write),
        .addra(w_mem_addr),
        .dina(w_bus_data),
        .douta(w_mem_read_data),
        .clkb(~clk),
        .web(uart_we),
        .addrb(uart_addr), // CPU�� ������ ������
        .dinb(uart_data),
        .doutb() // CPU�� �о ������
    );

endmodule