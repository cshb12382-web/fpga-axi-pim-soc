`timescale 1ns / 1ps

module debouncer #(parameter N = 10,        // create module debouncer with Parameters(N = 10, K = 4)
                   parameter K = 4)(
    input clk,                              // declare input signal clk
    input noisy,                            // declare input signal noisy
    output debounced                        // declare output signal debounced
    );

    reg [K-1:0] cnt;                        // declare internal signal type reg 'cnt' for K bit numbers

    always @ (posedge clk)                  // executes at rising edge of clk 
    begin
        if(noisy)                           // when noisy is 1
        cnt <= cnt + 1'b1;                  // cnt is cnt + 1
        else                                // when noisy is 0
        cnt <= 0;                           // cnt is 0
    end

    assign debounced = (cnt == N) ? 1'b1 : 1'b0; 
    // when cnt is same with N debounced is 1. if cnt isn't same with N debounced is 0

endmodule