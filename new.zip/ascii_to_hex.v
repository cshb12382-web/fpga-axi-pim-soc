`timescale 1ns / 1ps

module ascii_to_hex (
    input  wire [7:0] ascii_code,  // ASCII�? ?��?��?��?�� 문자
    output reg  [3:0] hex_value    // �??��?�� 4비트 16진수 �? (0x0~0xF)
);

    always @(*) begin
        case (ascii_code)
            // ?��?�� '0' ~ '9'
            8'h30: hex_value = 4'h0;  // ASCII("0") = 0x30 ?�� 4'h0
            8'h31: hex_value = 4'h1;  // ASCII("1") = 0x31 ?�� 4'h1
            8'h32: hex_value = 4'h2;  // ASCII("2") = 0x32 ?�� 4'h2
            8'h33: hex_value = 4'h3;  // ASCII("3") = 0x33 ?�� 4'h3
            8'h34: hex_value = 4'h4;  // ASCII("4") = 0x34 ?�� 4'h4
            8'h35: hex_value = 4'h5;  // ASCII("5") = 0x35 ?�� 4'h5
            8'h36: hex_value = 4'h6;  // ASCII("6") = 0x36 ?�� 4'h6
            8'h37: hex_value = 4'h7;  // ASCII("7") = 0x37 ?�� 4'h7
            8'h38: hex_value = 4'h8;  // ASCII("8") = 0x38 ?�� 4'h8
            8'h39: hex_value = 4'h9;  // ASCII("9") = 0x39 ?�� 4'h9

            // ??문자 'A' ~ 'F'
            8'h41: hex_value = 4'hA;  // ASCII("A") = 0x41 ?�� 4'hA
            8'h42: hex_value = 4'hB;  // ASCII("B") = 0x42 ?�� 4'hB
            8'h43: hex_value = 4'hC;  // ASCII("C") = 0x43 ?�� 4'hC
            8'h44: hex_value = 4'hD;  // ASCII("D") = 0x44 ?�� 4'hD
            8'h45: hex_value = 4'hE;  // ASCII("E") = 0x45 ?�� 4'hE
            8'h46: hex_value = 4'hF;  // ASCII("F") = 0x46 ?�� 4'hF

            // ?��문자 'a' ~ 'f'
            8'h61: hex_value = 4'hA;  // ASCII("a") = 0x61 ?�� 4'hA
            8'h62: hex_value = 4'hB;  // ASCII("b") = 0x62 ?�� 4'hB
            8'h63: hex_value = 4'hC;  // ASCII("c") = 0x63 ?�� 4'hC
            8'h64: hex_value = 4'hD;  // ASCII("d") = 0x64 ?�� 4'hD
            8'h65: hex_value = 4'hE;  // ASCII("e") = 0x65 ?�� 4'hE
            8'h66: hex_value = 4'hF;  // ASCII("f") = 0x66 ?�� 4'hF

            default: hex_value = 4'h0; // �? ?��?�� ASCII 문자?�� 0?���? 처리
        endcase
    end

endmodule