`timescale 1ns / 1ps

module freq_divide(     // create freq_div_1M module
    input clk_ref,      // declare input signal clk_ref
    input rst,          // declare input signal rst,
    output clk_div      // declare output signal clk_div
    );
    
    wire clk_1M, clk_10K, clk_100, clk_1;
    // declare internal signal clk_1M, clk_10K, clk_100, clk_1
    assign clk_1M = clk_ref;
    // clk_1M is clk_ref

    freq_div_100 u0 (.clk_ref(clk_1M),  .rst(rst), .clk_div(clk_10K));
    // freq_div_100(u0) generates clk_1M (divide clk_100M by 100) 
    freq_div_100 u1 (.clk_ref(clk_10K), .rst(rst), .clk_div(clk_100));
    // freq_div_100(u1) generates clk_100 (divide clk_10K by 100)
    freq_div_100 u2 (.clk_ref(clk_100), .rst(rst), .clk_div(clk_1));
    // freq_div_100(u2) generates clk_1 (divide clk_100 by 100)
    
    assign clk_div = clk_1;
    // clk_div is clk_1 = 50hz
    
endmodule

